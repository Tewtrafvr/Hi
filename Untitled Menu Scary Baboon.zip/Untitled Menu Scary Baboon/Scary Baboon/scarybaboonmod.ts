declare const Il2Cpp: any;
declare const console: any;
declare const System: any;
declare const XRNode: any;
declare const Random: any;
declare const UnityEngine: any;

let rigidbody = null

let thingforfling = null

let hue = 0;

let lastRunTime = 0;
let lastRgbTime = 0;
let playerScale = 1.0;
const strobecooldown = 300;
const rgbcooldown = 0;
const destroycooldown = 250;
const spawncooldown = 10; // ms between spawns when holding the spawn button
let lastSpawnTime = 0;

let invisible = false

let buttonClickDelay = 0.0;
let menu = null;
let menuBgRenderer = null;
let menuBg2Renderer = null;
let reference = null;
let referenceCollider = null;

let leftPrimary = false;
let leftSecondary = false;

let rightPrimary = false;
let rightSecondary = false;

let leftGrab = false;
let rightGrab = false;

let leftTrigger = false;
let rightTrigger = false;

let deltaTime = 0.0;
let time = 0.0;

let previousGhostKey = false;
let previousInvisKey = false;
let previousNoclipKey = false;
let perviousTeleportKey = false;

let closePosition = null;
let tagGunDelay = 0.0;
let tkLockedObject = null;
let orbitRadius = 0.5;
let orbitAngle = 0.0;
let orbitItems: any[] = [];
let lastOrbitScanTime = 0;
let kickTargetActorNum: number = -1;
let lastKickTime = 0;
let frozenTargets: number[] = [];

let leftPlatform = null;
let rightPlatform = null;

let lvT = null;
let rvT = null;

let bgColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
let bgColor2: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];

let textColor: [number, number, number, number] = [1.0, 1.0, 1.0, 1.0];

let buttonColor: [number, number, number, number] = [0.05, 0.05, 0.05, 1.0];
let buttonPressedColor: [number, number, number, number] = [0.35, 0.35, 0.35, 1.0];

let menuName: string = "Untitled Client";
let themeIndex = 10;

const themes = [
    { name: "Purple Haze",    bg: [0.05, 0.0, 0.08, 1.0],  bg2: [0.15, 0.0, 0.25, 1.0],  text: [0.85, 0.6, 1.0, 1.0],  btn: [0.12, 0.0, 0.2, 1.0],  btnOn: [0.45, 0.0, 0.7, 1.0]  },
    { name: "Blood Moon",     bg: [0.1, 0.0, 0.0, 1.0],    bg2: [0.25, 0.0, 0.0, 1.0],   text: [1.0, 0.4, 0.4, 1.0],   btn: [0.2, 0.0, 0.0, 1.0],   btnOn: [0.8, 0.0, 0.0, 1.0]   },
    { name: "Ocean Deep",     bg: [0.0, 0.05, 0.12, 1.0],  bg2: [0.0, 0.1, 0.25, 1.0],   text: [0.4, 0.85, 1.0, 1.0],  btn: [0.0, 0.08, 0.2, 1.0],  btnOn: [0.0, 0.3, 0.7, 1.0]   },
    { name: "Toxic",          bg: [0.02, 0.08, 0.0, 1.0],  bg2: [0.05, 0.2, 0.0, 1.0],   text: [0.5, 1.0, 0.2, 1.0],   btn: [0.04, 0.12, 0.0, 1.0], btnOn: [0.15, 0.6, 0.0, 1.0]  },
    { name: "Midnight Gold",  bg: [0.05, 0.04, 0.0, 1.0],  bg2: [0.12, 0.1, 0.0, 1.0],   text: [1.0, 0.85, 0.2, 1.0],  btn: [0.1, 0.08, 0.0, 1.0],  btnOn: [0.6, 0.5, 0.0, 1.0]   },
    { name: "Void Black",     bg: [0.02, 0.02, 0.02, 1.0], bg2: [0.06, 0.06, 0.06, 1.0], text: [0.9, 0.9, 0.9, 1.0],   btn: [0.08, 0.08, 0.08, 1.0],btnOn: [0.4, 0.4, 0.4, 1.0]   },
    { name: "Candy Pink",     bg: [0.12, 0.0, 0.06, 1.0],  bg2: [0.28, 0.0, 0.14, 1.0],  text: [1.0, 0.6, 0.85, 1.0],  btn: [0.2, 0.0, 0.1, 1.0],  btnOn: [0.9, 0.0, 0.4, 1.0]   },
    { name: "Arctic Ice",     bg: [0.0, 0.08, 0.1, 1.0],   bg2: [0.05, 0.18, 0.22, 1.0], text: [0.7, 0.95, 1.0, 1.0],  btn: [0.0, 0.1, 0.14, 1.0], btnOn: [0.0, 0.55, 0.75, 1.0] },
    { name: "Inferno",        bg: [0.1, 0.03, 0.0, 1.0],   bg2: [0.25, 0.08, 0.0, 1.0],  text: [1.0, 0.6, 0.1, 1.0],   btn: [0.18, 0.05, 0.0, 1.0], btnOn: [0.9, 0.3, 0.0, 1.0]   },
    { name: "Matrix",         bg: [0.0, 0.06, 0.0, 1.0],   bg2: [0.0, 0.14, 0.0, 1.0],   text: [0.0, 1.0, 0.3, 1.0],   btn: [0.0, 0.08, 0.0, 1.0], btnOn: [0.0, 0.6, 0.1, 1.0]   },
    { name: "RGB Rave",       bg: [0.0, 0.0, 0.0, 1.0],    bg2: [0.0, 0.0, 0.0, 1.0],    text: [1.0, 1.0, 1.0, 1.0],   btn: [0.05, 0.05, 0.05, 1.0], btnOn: [0.35, 0.35, 0.35, 1.0]},
] as const;

// ── Tooltip & Prefab Switcher globals ──
let currentTooltip: string = "";
let tooltipResetTime: number = 0;
let selectedPrefabIndex = 0;

const spawnablePrefabs: string[] = [
    // Sodas
    "LongArmSodaLvl1", "LongArmSodaLvl2", "SmallSoda", "SmallerSoda",
    "DreamSoda", "InvisibilitySoda", "JumpScareSoda", "RagdollSoda",
    "RageSoda", "SogSoda", "XraySoda", "MonsterXraySoda",
    // Guns
    "Shotgun", "Sniper", "Rifle", "GrenadeLauncher", "Glock",
    "SimpleHandGun", "FlareGun", "Rpg", "LuckyRevolver", "UnluckyGun",
    "WaterGun", "SuperSoakerGun", "BubbleGun",
    // Melee
    "WoodenBat", "SilverBat", "GoldenBat", "RustyPipe", "Stick",
    "Club", "Shank", "SlappingFish", "MetalThrowingAxe", "WoodenThrowingAxe",
    // Bows / Slingshots
    "WoodenBow", "MetalBow", "ScrappyBow", "WoodenSlingshot",
    "MetalSlingshot", "ScrappySlingshot", "CommandoSlingshot",
    // Grenades / Traps
    "Grenade", "ScrappyGrenade", "DanceGrenade", "GasMine", "StinkBomb",
    "GlueTrap", "MouseTrap",
    // Tools / Items
    "Flashlight", "ThrowingHook", "Telepearl", "WalkieTalkie",
    "PolaroidCamera", "PersonalFlag", "MonsterBait", "MonsterTracker",
    "ExtraLife", "LifeRing", "Frisbee", "Football", "VolleyBall",
    "WaterBalloon", "GiantWaterBalloon", "Ukulele",
    "JellyBeanMachine", "SlappingKit", "EpicBoomBox",
    // Pool Noodles
    "GreenPoolNoodle", "RedPoolNoodle",
    // Plushies
    "PlushieAngry", "PlushieBananaTracker", "PlushieBlackBaboon",
    "PlushieBlackGooGoo", "PlushieBlueBabbon", "PlushieCone",
    "PlushieMeatman", "PlushieWhiteBaboon", "PlushieWhiteMonster",
    // Ragdolls
    "RagdollV2", "BurnedBaboonRagdoll", "PoisonedBaboonRagdoll",
];

function setTooltip(text: string, duration: number = 4) {
    currentTooltip = text;
    tooltipResetTime = Date.now() + duration * 1000;
}

class XRInputHandler {
    private InputDevices: any;
    private tryGetFeatureValue: any;
    private buttonStates: Map<string, boolean>;

    constructor() {
        this.InputDevices = Il2Cpp.domain
            .assembly("UnityEngine.XRModule")
            .image.class("UnityEngine.XR.InputDevices");

        this.tryGetFeatureValue = this.InputDevices.method("TryGetFeatureValue_bool", 3);
        this.buttonStates = new Map();
    }

    update() {
        this.updateControllerStates(1);
        this.updateControllerStates(2);
    }

    private updateControllerStates(controllerId: number) {
        const features = [
            "PrimaryButton", "SecondaryButton", "GripButton",
            "TriggerButton", "MenuButton"
        ];
        features.forEach(feature => {
            const key = `${controllerId}_${feature}`;
            this.buttonStates.set(key, this.getButtonState(controllerId, feature));
        });
    }

    private getButtonState(deviceId: number, featureName: string): boolean {
        try {
            const valuePtr = Il2Cpp.alloc(1);
            const feature = Il2Cpp.string(featureName);
            const success = this.tryGetFeatureValue.invoke(uint64(deviceId), feature, valuePtr);
            if (success) {
                return valuePtr.readU8() !== 0;
            }
        } catch (_) { }
        return false;
    }

    isButtonPressed(controllerId: number, feature: string): boolean {
        return this.buttonStates.get(`${controllerId}_${feature}`) || false;
    }

    get leftControllerPrimaryButton(): boolean { return this.isButtonPressed(1, "PrimaryButton"); }
    get leftControllerSecondaryButton(): boolean { return this.isButtonPressed(1, "SecondaryButton"); }
    get rightControllerPrimaryButton(): boolean { return this.isButtonPressed(2, "PrimaryButton"); }
    get rightControllerSecondaryButton(): boolean { return this.isButtonPressed(2, "SecondaryButton"); }
    get leftGrab(): boolean { return this.isButtonPressed(1, "GripButton"); }
    get rightGrab(): boolean { return this.isButtonPressed(2, "GripButton"); }
    get leftControllerTriggerButton(): boolean { return this.isButtonPressed(1, "TriggerButton"); }
    get rightControllerTriggerButton(): boolean { return this.isButtonPressed(2, "TriggerButton"); }
    get controllerMenuButton(): boolean {
        return this.isButtonPressed(1, "MenuButton") || this.isButtonPressed(2, "MenuButton");
    }
}

Il2Cpp.perform(() => {
    const images = {
        "Assembly-CSharp": Il2Cpp.domain.assembly("Assembly-CSharp").image,
        "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
        "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
        "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
        "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
        "UnityEngine": Il2Cpp.domain.assembly("UnityEngine").image,
        "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
        "PhotonUnityNetworking": Il2Cpp.domain.assembly("PhotonUnityNetworking").image
    };
    const AssemblyCSharp = images["Assembly-CSharp"];
    const UnityEngineCore = images["UnityEngine.CoreModule"];
    const UnityEnginePhysics = images["UnityEngine.PhysicsModule"];
    const UnityEngineUI = images["UnityEngine.UI"];
    const UnityEngineUIModule = images["UnityEngine.UIModule"];
    const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
    const PhotonUnityNetworking = images["PhotonUnityNetworking"];

    const GTPlayerClass = AssemblyCSharp.class("GorillaLocomotion.Player");
    const GorillaReportButton = AssemblyCSharp.class("BaboonButton");
    const PhotonNetwork = PhotonUnityNetworking.class("Photon.Pun.PhotonNetwork");
    const PhotonView = PhotonUnityNetworking.class("Photon.Pun.PhotonView");
    const GTPlayer = GTPlayerClass.method("get_Instance").invoke();
    const GameObject = UnityEngineCore.class("UnityEngine.GameObject");
    const Object = UnityEngineCore.class("UnityEngine.Object");
    const Component = UnityEngineCore.class("UnityEngine.Component");
    const Vector3 = UnityEngineCore.class("UnityEngine.Vector3");
    const Quaternion = UnityEngineCore.class("UnityEngine.Quaternion");
    const Time = UnityEngineCore.class("UnityEngine.Time");
    const Resources = UnityEngineCore.class("UnityEngine.Resources");
    const Renderer = UnityEngineCore.class("UnityEngine.Renderer");
    const Shader = UnityEngineCore.class("UnityEngine.Shader");
    const RectTransform = UnityEngineCore.class("UnityEngine.RectTransform");
    const MeshCollider = UnityEnginePhysics.class("UnityEngine.Collider");
    const BoxCollider = UnityEnginePhysics.class("UnityEngine.BoxCollider");
    const Collider = UnityEnginePhysics.class("UnityEngine.Collider");
    const Rigidbody = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const Physics = UnityEnginePhysics.class("UnityEngine.Physics");
    const Canvas = UnityEngineUIModule.class("UnityEngine.Canvas");
    const CanvasScaler = UnityEngineUI.class("UnityEngine.UI.CanvasScaler");
    const GraphicRaycaster = UnityEngineUI.class("UnityEngine.UI.GraphicRaycaster");
    const Text = UnityEngineUI.class("UnityEngine.UI.Text");
    const Font = UnityEngineTextRendering.class("UnityEngine.Font");
    const GorillaTagger = GTPlayer;

    const NetworkPlayerSpawnerClass = AssemblyCSharp.class("NetworkPlayerSpawner");
    const NetworkPlayer = AssemblyCSharp.class("NetworkPlayer");
    const LineRenderer = UnityEngineCore.class("UnityEngine.LineRenderer");

    for (const field of GTPlayerClass.fields) {
        if (field.type.name == "UnityEngine.Rigidbody") {
            rigidbody = GTPlayer.field(field.name).value;
        }
    }

    const UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Lit"));
    const TextShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));

    const zeroVector = Vector3.field("zeroVector").value;
    const oneVector = Vector3.field("oneVector").value;
    const identityQuaternion = Quaternion.field("identityQuaternion").value;

    const leftHandTransform = GorillaTagger.field("leftHandTransform").value;
    const rightHandTransform = GorillaTagger.field("rightHandTransform").value;
    const headCollider = GorillaTagger.field("headCollider").value;

    const OVRInputHandler = new XRInputHandler();

    const arial = Resources
        .method("GetBuiltinResource", 1)
        .inflate(Font)
        .invoke(Il2Cpp.string("Arial.ttf"));

    function Destroy(object) {
        Object.method("Destroy", 1).invoke(object);
    }

    function getComponent(obj: any, type) {
        return obj.method("GetComponent", 1).inflate(type).invoke();
    }

    function addComponent(obj: any, type) {
        return obj.method("AddComponent", 1).inflate(type).invoke();
    }

    function getComponentInParent(obj: any, type) {
        return obj.method("GetComponentInParent", 0).inflate(type).invoke();
    }

    function getTransform(obj: any) {
        return obj.method("get_transform").invoke();
    }

    function sendAllOutgoing() {
        PhotonNetwork.method("SendAllOutgoingCommands").invoke();
    }

    function renderMenuText(
        canvasObject,
        text: string = "",
        color: [number, number, number, number] = [1, 1, 1, 1],
        pos = zeroVector,
        size = oneVector
    ) {
        const title = addComponent(createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(canvasObject)), Text);
        getComponent(title, BoxCollider).method("set_isTrigger").invoke(true);
        title.method("set_text").invoke(Il2Cpp.string(text));
        title.method("set_font").invoke(arial);
        title.method("set_fontSize").invoke(1);
        title.method("set_color").invoke(color);
        title.method("set_fontStyle").invoke(3);
        title.method("set_alignment").invoke(4);
        title.method("set_resizeTextForBestFit").invoke(true);
        title.method("set_resizeTextMinSize").invoke(0);

        const rectTransform = getComponent(title, RectTransform);
        rectTransform.method("set_sizeDelta").invoke(size);
        rectTransform.method("set_position").invoke(pos);
        rectTransform.method("set_rotation").invoke(Quaternion.method("Euler").invoke(180.0, 90.0, 90.0));
    }

    function createObject(
        pos = zeroVector,
        rot = identityQuaternion,
        scale = oneVector,
        primitiveType: number = 3,
        colorArr: [number, number, number, number] = [1, 1, 1, 1],
        parent = null
    ) {
        const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);
        const renderer = getComponent(obj, Renderer);

        if (colorArr[3] == 0) {
            renderer.method("set_enabled").invoke(false);
        } else {
            const material = renderer.method("get_material").invoke();
            material.method("set_shader").invoke(UberShader);
            material.method("set_color").invoke(colorArr);
        }

        const transform = getTransform(obj);
        if (parent != null) {
            transform.method("SetParent", 2).invoke(parent, false);
        }
        transform.method("set_position").invoke(pos);
        transform.method("set_rotation").invoke(rot);
        transform.method("set_localScale").invoke(scale);
        return obj;
    }

    //#region Movement helpers
    let platColor: [number, number, number, number] = [0.0, 0.0, 0.0, 1.0];
    const platColors: [number, number, number, number][] = [
        [0.0, 0.0, 0.0, 1.0],
        [9.0, 9.0, 9.0, 1.0],
        [9.0, 0.0, 0.0, 1.0],
        [0.0, 9.0, 0.0, 1.0],
        [0.0, 0.0, 9.0, 1.0],
        [5.0, 5.0, 0.0, 1.0],
        [9.0, 0.5, 9.0, 1.0],
    ];
    let platL = null;
    let platR = null;
    let plater = 0;

    function Platforms() {
        if (leftGrab) {
            if (platL == null) {
                const handTransform = leftHandTransform;
                platL = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.01, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platL != null) { Destroy(platL); platL = null; }
        }

        if (rightGrab) {
            if (platR == null) {
                const handTransform = rightHandTransform;
                platR = createObject(Vector3.method("op_Addition", 2).invoke(handTransform.method("get_position").invoke(), [0.0, -0.035, 0.0]), handTransform.method("get_rotation").invoke(), [0.025, 0.25, 0.3], 3, platColor);
            }
        } else {
            if (platR != null) { Destroy(platR); platR = null; }
        }
    }
    //#endregion

    //#region Server helpers
    function getLocalNetworkPlayer() {
        try {
            const allNetworkPlayers = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
            const localPhotonPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
            const localPlayerId = localPhotonPlayer.method("get_UserId").invoke().toString();

            for (let i = 0; i < allNetworkPlayers.length; i++) {
                const networkPlayer = allNetworkPlayers.get(i);
                try {
                    const photonView = networkPlayer.field("photonView").value;
                    if (photonView != null) {
                        const owner = photonView.method("get_Owner").invoke();
                        if (owner != null) {
                            const ownerId = owner.method("get_UserId").invoke().toString();
                            if (ownerId === localPlayerId) return networkPlayer;
                        }
                    }
                } catch (e) { continue; }
            }
            return null;
        } catch (e) { return null; }
    }

    function ClearRPC() {
        const LocalPlayer = PhotonNetwork.property("LocalPlayer").getValue(null);
        PhotonNetwork.method("RemoveRPCs", 1).invoke(null, LocalPlayer);
        PhotonNetwork.method("RemoveBufferedRPCs", 0).invoke(null);
        PhotonNetwork.field("MaxResendsBeforeDisconnect").value = 2147483647;
        PhotonNetwork.field("QuickResends").value = 2147483647;
        sendAllOutgoing();
    }
    //#endregion

    function renderMenu() {
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        Destroy(getComponent(menu, BoxCollider));

        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 0.86, 0.7], 3, bgColor, getTransform(menu));
        Destroy(getComponent(menuBackground, BoxCollider));
        menuBgRenderer = getComponent(menuBackground, Renderer);

        const menuBackground2 = createObject([0.1, 0, 0], identityQuaternion, [0.09, 0.88, 0.72], 3, bgColor2, getTransform(menu));
        Destroy(getComponent(menuBackground2, BoxCollider));
        menuBg2Renderer = getComponent(menuBackground2, Renderer);

        const canvasObject = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], getTransform(menu));
        const canvas = addComponent(canvasObject, Canvas);
        Destroy(getComponent(canvasObject, BoxCollider));

        const canvasScaler = addComponent(canvasObject, CanvasScaler);
        addComponent(canvasObject, GraphicRaycaster);
        canvas.method("set_renderMode").invoke(2);
        canvasScaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);

        const homeButton = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const homeButton2 = createObject([0.1, -0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        homeButton.method("set_name").invoke(Il2Cpp.string("@Home"));
        addComponent(homeButton, GorillaReportButton);
        getComponent(homeButton, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(canvasObject, "Home", textColor, [0.105, -0.06, 0.205], [0.15, 0.15]);

        const leaveButton = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.09, 0.2682, 0.075], 3, buttonColor, getTransform(menu));
        const leaveButton2 = createObject([0.1, 0.06, 0.205], identityQuaternion, [0.08, 0.3, 0.1], 3, bgColor2, getTransform(menu));
        leaveButton.method("set_name").invoke(Il2Cpp.string("@Leave"));
        addComponent(leaveButton, GorillaReportButton);
        getComponent(leaveButton, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(canvasObject, "Leave", textColor, [0.105, 0.06, 0.205], [0.15, 0.15]);

        // ── Title line — always shows "Untitled Client", theme name in tooltip area ──
        renderMenuText(canvasObject, `Untitled Client - Page [ <color=cyan>${currentPage + 1} </color>]`, textColor, [0.11, 0, 0.155], [1, .08]);

        // ── Tooltip: always show selected prefab when in Spawner category (9), otherwise show timed tooltip ──
        let tooltipText = "";
        if (currentCategory === 9) {
            tooltipText = `<color=cyan>Selected: ${spawnablePrefabs[selectedPrefabIndex]}</color>`;
        } else if (Date.now() < tooltipResetTime && currentTooltip !== "") {
            tooltipText = `<color=cyan>${currentTooltip}</color>`;
        }
        renderMenuText(canvasObject, tooltipText, textColor, [0.11, 0, 0.133], [1, 0.065]);

        {
            const pageButton = createObject([0.1, 0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, 0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));
            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, "<", textColor, [0.11, 0.17, 0], [1, 0.1]);
        }
        {
            const pageButton = createObject([0.1, -0.17, 0], identityQuaternion, [0.09, 0.15, 0.58], 3, buttonColor, getTransform(menu));
            const pageButton2 = createObject([0.1, -0.17, 0], identityQuaternion, [0.08, 0.16, 0.59], 3, bgColor2, getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));
            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, ">", textColor, [0.11, -0.17, 0], [1, 0.1]);
        }

        let i = 0;
        const targetMods = buttons[currentCategory]
            .slice(currentPage * 6)
            .slice(0, 6);

        targetMods.forEach((buttonData) => {
            const button = createObject([0.105, 0, 0.09 - (i * 0.04)], identityQuaternion, [0.09, 0.8, 0.08], 3, buttonColor, getTransform(menu));
            button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));
            addComponent(button, GorillaReportButton);
            getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(canvasObject, buttonData.buttonText, textColor, [0.11, 0, 0.09 - (i * 0.04)], [1, 0.1]);
            updateButtonColor(button, buttonData);
            i++;
        });

        recenterMenu();
    }

    function renderReference() {
        reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor2, rightHandTransform);
        referenceCollider = getComponent(reference, Collider);
        getTransform(reference).method("set_localPosition").invoke([0.01, 0, 0.2]);
        reference.method("set_layer").invoke(2);
        addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
    }

    let gunLocked = false;
    let lockTarget = null;
    let GunPointer = null;
    let GunLine = null;

    function renderGun(overrideLayerMask = null) {
        const StartPosition = rightHandTransform.method("get_position").invoke();
        const Direction = rightHandTransform.method("get_forward").invoke();
        // Start ray 0.4 units forward to skip hand/arm self-collision
        const DirectionOffset = Vector3.method("op_Multiply", 2).invoke(Direction, 0.4);
        const rayStartPosition = Vector3.method("op_Addition").invoke(StartPosition, DirectionOffset);
        const layerMask = overrideLayerMask || -3180559;

        const hits = Physics.method("RaycastAll", 4).invoke(
            rayStartPosition, Direction, 2048.0, layerMask
        );

        let finalDistance = Infinity;
        let finalRay = null;
        for (const hit of hits) {
            const distance = Vector3.method("Distance").invoke(hit.method("get_point").invoke(), StartPosition);
            // Ignore anything closer than 0.6 units — that's your own body
            if (distance < 0.6) continue;
            if (distance < finalDistance) { finalRay = hit; finalDistance = distance; }
        }

        let EndPosition;
        if (gunLocked) {
            EndPosition = getTransform(lockTarget).method("get_position").invoke();
        } else {
            EndPosition = finalRay.method("get_point").invoke();
        }

        if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
            const farDirection = Vector3.method("op_Multiply").invoke(Direction, 2048);
            EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
        }

        if (GunPointer == null) {
            GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
        }

        GunPointer.method("SetActive").invoke(true);
        const pointerTransform = getTransform(GunPointer);
        pointerTransform.method("set_position").invoke(EndPosition);

        const PointerRenderer = getComponent(GunPointer, Renderer);
        const material = PointerRenderer.method("get_material").invoke();
        material.method("set_shader").invoke(TextShader);
        const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
        material.method("set_color").invoke(pointerColor);

        const collider = getComponent(GunPointer, Collider);
        if (collider != null) Destroy(collider);

        // ── 3D Helix spring — pure JS math, single SetPosition call per point ──
        const springCoils = 3;
        const springWidth = 0.04;
        const pointsPerCoil = 12;
        const totalPoints = springCoils * pointsPerCoil + 1;

        // Extract components from IL2CPP Vector3 structs
        const sx = StartPosition.field("x").value as number;
        const sy = StartPosition.field("y").value as number;
        const sz = StartPosition.field("z").value as number;
        const ex = EndPosition.field("x").value as number;
        const ey = EndPosition.field("y").value as number;
        const ez = EndPosition.field("z").value as number;
        const hfx = Direction.field("x").value as number;
        const hfy = Direction.field("y").value as number;
        const hfz = Direction.field("z").value as number;

        // Fingertip offset 0.1 forward from hand
        const ftx = sx + hfx * 0.1;
        const fty = sy + hfy * 0.1;
        const ftz = sz + hfz * 0.1;

        // Ray direction (fingertip → end)
        let dx = ex - ftx, dy = ey - fty, dz = ez - ftz;
        const dlen = Math.sqrt(dx*dx + dy*dy + dz*dz) || 1;
        dx /= dlen; dy /= dlen; dz /= dlen;

        // Perp1: cross(dir, worldUp=[0,1,0]) = [-dz, 0, dx]
        let p1x = -dz, p1y = 0, p1z = dx;
        let p1len = Math.sqrt(p1x*p1x + p1y*p1y + p1z*p1z);
        if (p1len < 0.01) { p1x = dy; p1y = -dx; p1z = 0; p1len = Math.sqrt(p1x*p1x + p1y*p1y + p1z*p1z) || 1; }
        p1x /= p1len; p1y /= p1len; p1z /= p1len;

        // Perp2: cross(dir, perp1)
        const p2x = dy*p1z - dz*p1y;
        const p2y = dz*p1x - dx*p1z;
        const p2z = dx*p1y - dy*p1x;

        if (GunLine == null) {
            const lineGO = GameObject.method("CreatePrimitive").invoke(3);
            Destroy(getComponent(lineGO, Collider));
            getComponent(lineGO, Renderer).method("set_enabled").invoke(false);
            const lr = addComponent(lineGO, LineRenderer);
            lr.method("set_useWorldSpace").invoke(true);
            lr.method("set_positionCount").invoke(totalPoints);
            lr.method("set_startWidth").invoke(0.008);
            lr.method("set_endWidth").invoke(0.008);
            const lrMat = lr.method("get_material").invoke();
            lrMat.method("set_shader").invoke(TextShader);
            lrMat.method("set_color").invoke(buttonPressedColor);
            GunLine = lr;
        }

        GunLine.method("set_positionCount").invoke(totalPoints);
        for (let p = 0; p < totalPoints; p++) {
            const t = p / (totalPoints - 1);
            const angle = t * springCoils * Math.PI * 2;
            const taper = Math.sin(t * Math.PI) * springWidth;
            const cosA = Math.cos(angle) * taper;
            const sinA = Math.sin(angle) * taper;
            GunLine.method("SetPosition").invoke(p, [
                ftx + dx * dlen * t + p1x * cosA + p2x * sinA,
                fty + dy * dlen * t + p1y * cosA + p2y * sinA,
                ftz + dz * dlen * t + p1z * cosA + p2z * sinA
            ]);
        }
        GunLine.method("get_gameObject").invoke().method("SetActive").invoke(true);

        return { ray: finalRay, gunPointer: GunPointer };
    }

    function recenterMenu() {
        let menuPosition = leftHandTransform.method("get_position").invoke();
        let menuRotation = leftHandTransform.method("get_rotation").invoke();
        menuRotation = Quaternion.method("op_Multiply", 2).invoke(menuRotation, Quaternion.method("Euler").invoke(-45, 0, 0));
        const menuTransform = getTransform(menu);
        menuTransform.method("set_position").invoke(menuPosition);
        menuTransform.method("set_rotation").invoke(menuRotation);
    }

    function reloadMenu() {
        if (menu != null) {
            Object.method("Destroy", 1).invoke(menu);
            menu = null;
        }
    }

    function updateButtonColor(button, buttonData) {
        const RendererClass = Il2Cpp.domain
            .assembly("UnityEngine.CoreModule")
            .image.class("UnityEngine.Renderer");
        const renderer = getComponent(button, RendererClass);
        if (!renderer) return;
        const material = renderer.method("get_material").invoke();
        material.method("set_color").invoke(buttonData.enabled ? buttonPressedColor : buttonColor);
    }

    function toggleColliders(enabled) {
        // Only toggle static geometry colliders — skip players, network objects, triggers
        const colliders = Object.method("FindObjectsOfType").inflate(Collider).invoke();
        for (let i = 0; i < colliders.length; i++) {
            try {
                const col = colliders.get(i);
                if (referenceCollider && col.handle.equals(referenceCollider.handle)) continue;
                const isTrigger = col.method("get_isTrigger").invoke() as boolean;
                if (isTrigger) continue;
                // Skip colliders on network objects (players, items)
                const go = col.method("get_gameObject").invoke();
                const hasPV = go.method("GetComponent", 1).inflate(PhotonView).invoke();
                if (hasPV && !hasPV.isNull()) continue;
                col.method("set_enabled").invoke(enabled);
            } catch(_) {}
        }
        if (enabled) {
            try { rigidbody.method("set_velocity").invoke(zeroVector); } catch(_) {}
        }
    }

    function hsl2Rgb(h, s, l) {
        s /= 100; l /= 100;
        const k = (n) => (n + h / 30) % 12;
        const a = s * Math.min(l, 1 - l);
        const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
        return [Math.round(255 * f(0)), Math.round(255 * f(8)), Math.round(255 * f(4))];
    }

    function getSmoothColor() {
        hue = (hue + 2) % 360;
        const [r, g, b] = hsl2Rgb(hue, 100, 50);
        return { r: r / 255, g: g / 255, b: b / 255, a: 1.0 };
    }

    interface ButtonInfoConfig {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn?: boolean;
        enabled?: boolean;
        tooltip?: string;
    }

    class ButtonInfo {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        keepOn: boolean;
        enabled: boolean;
        tooltip: string;

        constructor(config: ButtonInfoConfig) {
            this.buttonText = config.buttonText;
            this.method = config.method;
            this.enableMethod = config.enableMethod;
            this.disableMethod = config.disableMethod;
            this.keepOn = config.keepOn ?? true;
            this.enabled = config.enabled ?? false;
            this.tooltip = config.tooltip ?? "";
        }
    }

    // ── World-space HUD notification system ──
    let hudNotifObject = null;
    let hudTextComponent = null;
    let hudNotifExpiry = 0;

    const NOTIF_SLOTS = 4;
    const notifSlots: { go: any, text: any, expiry: number }[] = [];
    let notifSlotsReady = false;

    function initNotifSlots() {
        if (notifSlotsReady) return;
        try {
            // Root anchor parented to head
            hudNotifObject = GameObject.method("CreatePrimitive").invoke(3);
            getComponent(hudNotifObject, Renderer).method("set_enabled").invoke(false);
            try { Destroy(getComponent(hudNotifObject, Collider)); } catch(_) {}
            try { Destroy(getComponent(hudNotifObject, BoxCollider)); } catch(_) {}
            hudNotifObject.method("set_layer").invoke(2);
            const rootTf = getTransform(hudNotifObject);
            rootTf.method("SetParent", 2).invoke(getTransform(headCollider), false);
            rootTf.method("set_localPosition").invoke([0, -0.25, 1.4]);
            rootTf.method("set_localRotation").invoke(Quaternion.method("Euler").invoke(0, 0, 0));
            rootTf.method("set_localScale").invoke([0.22, 0.22, 0.22]);

            for (let s = 0; s < NOTIF_SLOTS; s++) {
                const slotGO = GameObject.method("CreatePrimitive").invoke(3);
                getComponent(slotGO, Renderer).method("set_enabled").invoke(false);
                try { Destroy(getComponent(slotGO, Collider)); } catch(_) {}
                try { Destroy(getComponent(slotGO, BoxCollider)); } catch(_) {}
                slotGO.method("set_layer").invoke(2);
                const slotTf = getTransform(slotGO);
                slotTf.method("SetParent", 2).invoke(rootTf, false);
                slotTf.method("set_localPosition").invoke([0, -s * 0.22, 0]);
                slotTf.method("set_localScale").invoke([1, 1, 1]);
                const canvas = addComponent(slotGO, Canvas);
                canvas.method("set_renderMode").invoke(2);
                const scaler = addComponent(slotGO, CanvasScaler);
                scaler.method("set_dynamicPixelsPerUnit").invoke(1000.0);
                addComponent(slotGO, GraphicRaycaster);
                const txtComp = addComponent(slotGO, Text);
                txtComp.method("set_font").invoke(arial);
                txtComp.method("set_fontSize").invoke(1);
                txtComp.method("set_fontStyle").invoke(1);
                txtComp.method("set_alignment").invoke(3); // left
                txtComp.method("set_resizeTextForBestFit").invoke(true);
                txtComp.method("set_resizeTextMinSize").invoke(0);
                txtComp.method("set_text").invoke(Il2Cpp.string(""));
                const rt = getComponent(txtComp, RectTransform);
                rt.method("set_sizeDelta").invoke([1.4, 0.2]);
                slotGO.method("SetActive").invoke(false);
                notifSlots.push({ go: slotGO, text: txtComp, expiry: 0 });
            }
            notifSlotsReady = true;
        } catch(_) {}
    }

    function showNotification(text: string, duration: number = 2.5) {
        initNotifSlots(); // ensure slots exist before trying to use them
        if (!notifSlotsReady) return;
        try {
            let slot = notifSlots.find(s => Date.now() > s.expiry);
            if (!slot) slot = notifSlots.reduce((a, b) => a.expiry < b.expiry ? a : b);
            // "Notification:" always red, description white
            slot.text.method("set_text").invoke(Il2Cpp.string(
                `<color=red>Notification:</color> <color=white>${text}</color>`
            ));
            slot.go.method("SetActive").invoke(true);
            slot.expiry = Date.now() + duration * 1000;
        } catch(_) {}
    }

    function rgbToHex(r: number, g: number, b: number): string {
        const toHex = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, "0");
        return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
    }

    // ── Player join/leave detection ──
    let lastPlayerCount = -1;
    let knownPlayerActors: Set<number> = new Set();
    let currentCategory = 0;
    let currentPage = 0;
    let flyspeed = 5.0;
    let ghost = false;

    const buttons: ButtonInfo[][] = [
        [ // Home [0]
            new ButtonInfo({ buttonText: "⚙ Settings",    method: () => { currentCategory = 2; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "🏃 Movement",   method: () => { currentCategory = 3; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "🎭 Misc",       method: () => { currentCategory = 4; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "💀 OP Mods",    method: () => { currentCategory = 5; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "🔫 Weapons",    method: () => { currentCategory = 6; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "✨ Effects",    method: () => { currentCategory = 7; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "👾 Monsters",   method: () => { currentCategory = 8; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "📦 Spawner",    method: () => { currentCategory = 9; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "🎯 Player Guns",method: () => { currentCategory = 10; currentPage = 0; }, keepOn: false }),
            new ButtonInfo({ buttonText: "⚡ Physics",    method: () => { currentCategory = 11; currentPage = 0; }, keepOn: false }),
        ],
        [ // Menu Buttons [1]
            new ButtonInfo({
                buttonText: "Leave",
                method: () => PhotonNetwork.method("LeaveRoom", 1).invoke(true),
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Home",
                method: () => { currentCategory = 0; currentPage = 0; },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "PreviousPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;
                    currentPage--;
                    if (currentPage < 0) currentPage = lastPage;
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "NextPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 6) - 1;
                    currentPage++;
                    currentPage %= lastPage + 1;
                },
                keepOn: false,
            }),
        ],
        [ // Settings [2]
            new ButtonInfo({ buttonText: `Fly Speed+`, method: () => { flyspeed += 1; reloadMenu(); }, keepOn: false, tooltip: "Increases fly speed by 1" }),
            new ButtonInfo({ buttonText: `Fly Speed-`, method: () => { flyspeed -= 1; reloadMenu(); }, keepOn: false, tooltip: "Decreases fly speed by 1" }),
            new ButtonInfo({ buttonText: "Platform Color", method: () => { plater = (plater + 1) % platColors.length; platColor = platColors[plater]; }, keepOn: false, tooltip: "Cycles through platform colors" }),
            new ButtonInfo({ buttonText: "Next Theme", method: () => { themeIndex = (themeIndex + 1) % themes.length; const t = themes[themeIndex]; bgColor = [...t.bg] as [number,number,number,number]; bgColor2 = [...t.bg2] as [number,number,number,number]; textColor = [...t.text] as [number,number,number,number]; buttonColor = [...t.btn] as [number,number,number,number]; buttonPressedColor = [...t.btnOn] as [number,number,number,number]; setTooltip(`Theme: ${t.name}`, 3); reloadMenu(); }, keepOn: false, tooltip: "Switches to the next menu color theme" }),
            new ButtonInfo({ buttonText: "Prev Theme", method: () => { themeIndex = (themeIndex - 1 + themes.length) % themes.length; const t = themes[themeIndex]; bgColor = [...t.bg] as [number,number,number,number]; bgColor2 = [...t.bg2] as [number,number,number,number]; textColor = [...t.text] as [number,number,number,number]; buttonColor = [...t.btn] as [number,number,number,number]; buttonPressedColor = [...t.btnOn] as [number,number,number,number]; setTooltip(`Theme: ${t.name}`, 3); reloadMenu(); }, keepOn: false, tooltip: "Switches to the previous menu color theme" }),
        ],
        [ // Movement Mods [3]
            new ButtonInfo({
                buttonText: "Fly [B]",
                tooltip: "Hold B to fly in the direction you point your right hand",
                method: () => {
                    if (rightSecondary) {
                        const leftRightVector = rightHandTransform.method("get_forward").invoke();
                        const leftForce = Vector3.method("op_Multiply", 2).invoke(leftRightVector, flyspeed);
                        rigidbody.method("set_velocity").invoke(leftForce);
                    }
                },
            }),
            new ButtonInfo({ buttonText: "Platforms [G]", method: () => Platforms(), tooltip: "Hold left/right grip to create solid platforms under your hands" }),
            new ButtonInfo({
                buttonText: "No Clip",
                tooltip: "Hold trigger to walk through walls, release to restore collisions",
                method: () => {
                    if (rightTrigger && !previousNoclipKey) toggleColliders(false);
                    if (!rightTrigger && previousNoclipKey) toggleColliders(true);
                    previousNoclipKey = rightTrigger;
                },
            }),
            new ButtonInfo({
                buttonText: "Super Jump",
                tooltip: "Pull trigger to launch yourself straight up",
                method: () => {
                    if (rightTrigger && !perviousTeleportKey) {
                        rigidbody.method("set_velocity").invoke([0, 35.0, 0]);
                    }
                    perviousTeleportKey = rightTrigger;
                },
            }),
            new ButtonInfo({
                buttonText: "Low Gravity",
                tooltip: "Toggle to float slowly instead of falling normally",
                enabled: false,
                method: () => {
                    try { rigidbody.method("set_useGravity").invoke(false); } catch(_) {}
                    // Apply tiny downward force so you still fall slowly
                    const vel = rigidbody.method("get_velocity").invoke();
                    const vx = vel.field("x").value as number;
                    const vy = vel.field("y").value as number;
                    const vz = vel.field("z").value as number;
                    rigidbody.method("set_velocity").invoke([vx, Math.max(vy - 0.05, -2.0), vz]);
                },
                disableMethod: () => {
                    try { rigidbody.method("set_useGravity").invoke(true); } catch(_) {}
                },
            }),
            new ButtonInfo({
                buttonText: "TP to Gun",
                tooltip: "Hold grip + pull trigger to teleport to wherever you're aiming",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            const px = pos.field("x").value as number;
                            const py = pos.field("y").value as number;
                            const pz = pos.field("z").value as number;
                            // Set both transform and rigidbody position, zero velocity
                            try { rigidbody.method("set_velocity").invoke(zeroVector); } catch(_) {}
                            try { rigidbody.method("set_position").invoke(pos); } catch(_) {}
                            try { getTransform(GTPlayer.method("get_gameObject").invoke()).method("set_position").invoke(pos); } catch(_) {}
                            // Also move head collider
                            try { getTransform(headCollider).method("set_position").invoke([px, py + 0.5, pz]); } catch(_) {}
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Monke Scaler 🥵",
                tooltip: "Right trigger to grow, left trigger to shrink your player scale",
                enabled: false,
                method: () => {
                    // Right trigger = grow, left trigger = shrink
                    if (rightTrigger) {
                        playerScale = Math.min(playerScale + 0.05, 10.0);
                    } else if (leftTrigger) {
                        playerScale = Math.max(playerScale - 0.05, 0.1);
                    }
                    // Apply scale to all relevant Player fields
                    for (const field of GTPlayerClass.fields) {
                        try {
                            const fn = field.name.toLowerCase();
                            if (field.type.name === "System.Single") {
                                if (fn.includes("scale")) GTPlayer.field(field.name).value = playerScale;
                            }
                        } catch (_) {}
                    }
                    try { GTPlayer.field("scale").value = playerScale; } catch (_) {}
                },
                disableMethod: () => {
                    playerScale = 1.0;
                    for (const field of GTPlayerClass.fields) {
                        try {
                            const fn = field.name.toLowerCase();
                            if (field.type.name === "System.Single") {
                                if (fn.includes("scale")) GTPlayer.field(field.name).value = 1.0;
                            }
                        } catch (_) {}
                    }
                    try { GTPlayer.field("scale").value = 1.0; } catch (_) {}
                },
            }),
            new ButtonInfo({
                buttonText: "Speed Boost",
                tooltip: "Increases your max jump/movement speed significantly",
                enabled: false,
                method: () => { GTPlayer.field("maxJumpSpeed").value = 29.5; },
            }),
            new ButtonInfo({
                buttonText: "Ghost Monkey",
                tooltip: "Press B to toggle your network player on/off, making you invisible",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 500) {
                            lastRunTime = now;
                            ghost = !ghost;
                            const localNetworkPlayer = getLocalNetworkPlayer();
                            if (localNetworkPlayer != null) {
                                localNetworkPlayer.method("set_enabled").invoke(!ghost);
                            }
                        }
                    }
                },
            }),
        ],
        [ // Misc Mods [4]
            new ButtonInfo({
                buttonText: "Open Staff",
                tooltip: "Destroys the mod detection object to bypass staff checks",
                method: () => { Destroy(GameObject.method("Find").invoke(Il2Cpp.string("Mod"))); },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "J0kerModZ Name",
                tooltip: "Sets your display name to the J0kerModZ tag",
                method: () => {
                    const name = "<size=100><sprite=12>J0kerModZ<sprite=12>";
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(name));
                },
                keepOn: false,
            }),

            new ButtonInfo({
                buttonText: "RGB",
                tooltip: "Smoothly cycles your player color through the rainbow",
                method: () => {
                    const now = Date.now();
                    if (now - lastRgbTime >= rgbcooldown) {
                        lastRgbTime = now;
                        const c = getSmoothColor();
                        NetworkPlayerSpawnerClass.method("SetColor").invoke([c.r, c.g, c.b, c.a]);
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "J0ker Pink",
                tooltip: "Sets your player color to the J0ker signature pink",
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime >= strobecooldown) {
                        lastRunTime = now;
                        NetworkPlayerSpawnerClass.method("SetColor").invoke([-9990, 0, 0, 0]);
                    }
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Freeze Item Gun",
                tooltip: "Aim at your spawned item and pull trigger to freeze it in place",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            const gunPos = getTransform(gunPointer).method("get_position").invoke();
                            const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                            const photonViews = Object.method("FindObjectsOfType").inflate(PhotonView).invoke();
                            let closestDist = 3.0;
                            let targetObj = null;
                            for (let i = 0; i < photonViews.length; i++) {
                                try {
                                    const pv = photonViews.get(i);
                                    const owner = pv.method("get_Owner").invoke();
                                    if (owner == null || owner.method("get_ActorNumber").invoke() !== localId) continue;
                                    const obj = pv.method("get_gameObject").invoke();
                                    const name = obj.method("get_name").invoke().toString();
                                    if (!spawnablePrefabs.some(p => name.includes(p))) continue;
                                    const dist = Vector3.method("Distance").invoke(gunPos, getTransform(obj).method("get_position").invoke());
                                    if (dist < closestDist) { closestDist = dist; targetObj = obj; }
                                } catch(_) {}
                            }
                            if (targetObj != null) {
                                try {
                                    const rb = getComponent(targetObj, Rigidbody);
                                    if (rb != null) {
                                        rb.method("set_isKinematic").invoke(true);
                                        rb.method("set_velocity").invoke(zeroVector);
                                        rb.method("set_angularVelocity").invoke(zeroVector);
                                    }
                                } catch(_) {}
                            }
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Custom Name",
                tooltip: "Sets a random styled display name from a preset list",
                method: () => {
                    const names = [
                        "<color=red>☠ HACKER ☠</color>",
                        "<color=cyan>👑 GOD 👑</color>",
                        "<color=#FF00FF>✨ MOD ✨</color>",
                        "<color=yellow>⚡ ZEUS ⚡</color>",
                        "<color=#00FF00>🌀 GHOST 🌀</color>",
                    ];
                    const picked = names[Math.floor(Math.random() * names.length)];
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(picked));
                },
                keepOn: false,
            }),
        ],
        [ // OP Mods [5]
            new ButtonInfo({
                buttonText: "Set Master",
                tooltip: "Claims master client authority over the room",
                method: () => {
                    const room = PhotonNetwork.method("get_CurrentRoom").invoke();
                    const localPlayer = PhotonNetwork.method("get_LocalPlayer").invoke();
                    const wasMaster = PhotonNetwork.method("get_IsMasterClient").invoke();
                    const result = room.method("SetMasterClient").invoke(localPlayer);
                    console.log(`[SetMaster] wasMaster=${wasMaster} result=${result} - waiting for server...`);
                    setTimeout(() => {
                        const isMasterNow = PhotonNetwork.method("get_IsMasterClient").invoke();
                        console.log(`[SetMaster] isMasterNow (after 1s)=${isMasterNow}`);
                    }, 1000);
                    setTimeout(() => {
                        const isMasterNow = PhotonNetwork.method("get_IsMasterClient").invoke();
                        console.log(`[SetMaster] isMasterNow (after 3s)=${isMasterNow}`);
                    }, 3000);
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Bring All",
                tooltip: "Teleports all other players to your position instantly",
                method: () => {
                    try {
                        const myPos = getTransform(GTPlayer.method("get_gameObject").invoke()).method("get_position").invoke();
                        const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                        const allNetworkPlayers = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
                        for (let i = 0; i < allNetworkPlayers.length; i++) {
                            try {
                                const np = allNetworkPlayers.get(i);
                                const pv = np.field("photonView").value;
                                if (pv == null) continue;
                                const owner = pv.method("get_Owner").invoke();
                                if (owner == null) continue;
                                if (owner.method("get_ActorNumber").invoke() === localId) continue;
                                const npGO = np.method("get_gameObject").invoke();
                                getTransform(npGO).method("set_position").invoke(myPos);
                                // Also zero out their velocity so they don't slide away
                                let rb = getComponent(npGO, Rigidbody);
                                if (rb == null) rb = getComponentInParent(npGO, Rigidbody);
                                if (rb != null) rb.method("set_velocity").invoke(zeroVector);
                            } catch (_) {}
                        }
                    } catch (_) {}
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Rig Spam",
                tooltip: "Press B to spam clone rigs into the room",
                method: () => {
                    if (rightSecondary) {
                        const now = Date.now();
                        if (now - lastRunTime >= 0.1) {
                            lastRunTime = now;
                            const clonedrig = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonNetworkPlayer_SquidGame"), getTransform(headCollider).method("get_position").invoke(), identityQuaternion, 0, NULL);
                            const components = clonedrig.method("GetComponents", 0).inflate(Component).invoke();
                            for (let i = 0; i < components.length; i++) {
                                const component = components.get(i);
                                const name = component.method("GetType", 0).invoke().method("get_Name").invoke().toString();
                                if (name.includes("BaboonNetworkPlayer_SquidGame")) {
                                    setTimeout(function () { Destroy(component); }, 150);
                                }
                            }
                        }
                        sendAllOutgoing();
                        ClearRPC();
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Gore Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("RagdollV2"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Fighter Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFighterNetwork"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Miner Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonMiner"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Hammer Rig Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BaboonFling"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Crash All",
                tooltip: "Spawns 1000 objects instantly to crash all players in the room",
                method: () => {
                    for (let i = 0; i < 1000; i++) {
                        const thingforlag = PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ShotgunCommon"), [100.0, -100.0, 0.0], identityQuaternion, 0, NULL);
                        Destroy(thingforlag);
                    }
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Destroy All",
                method: () => {
                    const others = PhotonNetwork.method("get_PlayerListOthers").invoke();
                    if (others && others.length > 0) {
                        for (let i = 0; i < others.length; i++) {
                            const player = others.get(i);
                            PhotonNetwork.method("get_CurrentRoom").invoke().method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
                            PhotonNetwork.method("DestroyPlayerObjects").invoke(player);
                        }
                    }
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Fake Lag All",
                method: () => {
                    // Spam tiny instantiates to flood Photon outgoing buffer and lag everyone
                    const now = Date.now();
                    if (now - lastRunTime < 50) return;
                    lastRunTime = now;
                    for (let i = 0; i < 20; i++) {
                        try {
                            const obj = PhotonNetwork.method("Instantiate", 5).invoke(
                                Il2Cpp.string("ShotgunCommon"), [0, -9999, 0], identityQuaternion, 0, NULL
                            );
                            Destroy(obj);
                        } catch(_) {}
                    }
                    sendAllOutgoing();
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Spam Name",
                enabled: false,
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime < 500) return;
                    lastRunTime = now;
                    const glitchChars = "▓▒░█▄▌▐▀■□▪▫◘◙◦";
                    let name = "";
                    for (let i = 0; i < 12; i++) name += glitchChars[Math.floor(Math.random() * glitchChars.length)];
                    PhotonNetwork.method("set_NickName").invoke(Il2Cpp.string(`<color=#${Math.floor(Math.random()*0xFFFFFF).toString(16).padStart(6,"0")}>${name}</color>`));
                },
            }),
            new ButtonInfo({
                buttonText: "Big Head",
                enabled: false,
                method: () => {
                    try {
                        const headTransform = getTransform(headCollider);
                        headTransform.method("set_localScale").invoke([3.0, 3.0, 3.0]);
                    } catch(_) {}
                },
                disableMethod: () => {
                    try {
                        const headTransform = getTransform(headCollider);
                        headTransform.method("set_localScale").invoke(oneVector);
                    } catch(_) {}
                },
            }),
            new ButtonInfo({
                buttonText: "Auto Leave",
                enabled: false,
                method: () => {
                    const now = Date.now();
                    if (now - lastRunTime < 10000) return;
                    lastRunTime = now;
                    PhotonNetwork.method("LeaveRoom", 1).invoke(true);
                },
            }),
        ],
        [ // Weapon Spawn [6]
            new ButtonInfo({
                buttonText: "SMG",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SMGCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Shotgun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ShotgunCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Scar",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ScarCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Grenade Launcher",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("GrenadeLauncherCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Pistol",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("FootballParent"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Sniper",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("SniperCommon"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                    }
                },
            }),
        ],
        [ // Effects [7]
            new ButtonInfo({
                buttonText: "Flare [T]",
                method: () => {
                    if (rightTrigger) {
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Flare"), rightHandTransform.method("get_position").invoke(), rightHandTransform.method("get_rotation").invoke(), 0, NULL);
                        sendAllOutgoing(); ClearRPC();
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Lighting [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Lighting"), pos, [707, 707, 0, 0], 0, NULL);
                        sendAllOutgoing(); ClearRPC();
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Explosion [T]",
                method: () => {
                    if (rightTrigger) {
                        const pos = rightHandTransform.method("get_position").invoke();
                        PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("BigExplosion"), pos, identityQuaternion, 0, NULL);
                        sendAllOutgoing(); ClearRPC();
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Confetti Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Confetti"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Macarena Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("AMacrena"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Fein Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Fein"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "LadyHear Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ladyhear"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "TylerTheCreator Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TylerTheCreator"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Tect Talking Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("TectAudio"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Splash Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("Splash"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Plane Sound",
                method: () => {
                    const pos = rightHandTransform.method("get_position").invoke();
                    PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("ImBoutaBombThisPlane"), pos, identityQuaternion, 0, NULL);
                    sendAllOutgoing(); ClearRPC();
                },
                keepOn: false,
            }),
        ],
        [ // Monster Mods [8]
            new ButtonInfo({
                buttonText: "Big Larry Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/BigLarry"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
            new ButtonInfo({
                buttonText: "Meat Man Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            const pos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("Instantiate", 5).invoke(Il2Cpp.string("monsters/MeatMan"), pos, identityQuaternion, 0, NULL);
                            sendAllOutgoing(); ClearRPC();
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
            }),
        ],
        [ // Spawner [9]
            new ButtonInfo({
                buttonText: "< Prev",
                method: () => {
                    selectedPrefabIndex = (selectedPrefabIndex - 1 + spawnablePrefabs.length) % spawnablePrefabs.length;
                    reloadMenu();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Next >",
                method: () => {
                    selectedPrefabIndex = (selectedPrefabIndex + 1) % spawnablePrefabs.length;
                    reloadMenu();
                },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Spawn Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger) {
                            const now = Date.now();
                            if (now - lastSpawnTime >= spawncooldown) {
                                lastSpawnTime = now;
                                const pos = getTransform(gunPointer).method("get_position").invoke();
                                try {
                                    PhotonNetwork.method("Instantiate", 5).invoke(
                                        Il2Cpp.string(spawnablePrefabs[selectedPrefabIndex]),
                                        pos, identityQuaternion, 0, NULL
                                    );
                                    sendAllOutgoing();
                                    ClearRPC();
                                } catch (_) {}
                            }
                        }
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Spawn At Hand",
                method: () => {
                    if (rightTrigger) {
                        const now = Date.now();
                        if (now - lastSpawnTime >= spawncooldown) {
                            lastSpawnTime = now;
                            const pos = rightHandTransform.method("get_position").invoke();
                            try {
                                PhotonNetwork.method("Instantiate", 5).invoke(
                                    Il2Cpp.string(spawnablePrefabs[selectedPrefabIndex]),
                                    pos, identityQuaternion, 0, NULL
                                );
                                sendAllOutgoing();
                                ClearRPC();
                            } catch (_) {}
                        }
                    }
                    perviousTeleportKey = rightTrigger;
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Despawn All",
                method: () => {
                    // Grab master client authority first so we can destroy anyone's objects
                    PhotonNetwork.method("get_CurrentRoom").invoke().method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
                    setTimeout(() => {
                    const photonViews = Object.method("FindObjectsOfType").inflate(PhotonView).invoke();
                    for (let i = 0; i < photonViews.length; i++) {
                        try {
                            const pv = photonViews.get(i);
                            if (pv == null) continue;
                            const obj = pv.method("get_gameObject").invoke();
                            const name = obj.method("get_name").invoke().toString();
                            if (spawnablePrefabs.some(p => name.includes(p))) {
                                PhotonNetwork.method("Destroy", 1).invoke(obj);
                            }
                        } catch (_) {}
                    }
                    sendAllOutgoing();
                    ClearRPC();
                    }, 1500);
                },
                keepOn: false,
            }),
        ],
        [ // Player Guns [10]
            new ButtonInfo({
                buttonText: "Kick Gun",
                enabled: false,
                method: () => {
                    if (rightGrab) {
                        renderGun();
                        // Trigger = add/remove target from frozen list
                        if (rightTrigger && !perviousTeleportKey) {
                            const gunData = renderGun();
                            let targetNP = null;
                            try {
                                const ray = gunData.ray;
                                if (ray && !ray.handle?.isNull?.()) {
                                    const hitCollider = ray.method("get_collider").invoke();
                                    if (hitCollider && !hitCollider.isNull()) {
                                        try { targetNP = hitCollider.method("GetComponentInParent", 0).inflate(NetworkPlayer).invoke(); } catch(_) {}
                                        if (!targetNP || targetNP.isNull?.()) {
                                            try { targetNP = hitCollider.method("get_gameObject").invoke().method("GetComponentInParent", 0).inflate(NetworkPlayer).invoke(); } catch(_) {}
                                        }
                                    }
                                }
                            } catch(_) {}
                            if (!targetNP || targetNP.isNull?.()) {
                                const rayOrigin = rightHandTransform.method("get_position").invoke();
                                const rayDir = rightHandTransform.method("get_forward").invoke();
                                const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                                const allNPs = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
                                let bestDist = 3.0;
                                for (let i = 0; i < allNPs.length; i++) {
                                    try {
                                        const np = allNPs.get(i);
                                        const pv = np.field("photonView").value;
                                        if (pv == null) continue;
                                        const owner = pv.method("get_Owner").invoke();
                                        if (owner == null || owner.method("get_ActorNumber").invoke() === localId) continue;
                                        const npPos = getTransform(np.method("get_gameObject").invoke()).method("get_position").invoke();
                                        const toTarget = Vector3.method("op_Subtraction", 2).invoke(npPos, rayOrigin);
                                        const dot = Vector3.method("Dot").invoke(toTarget, rayDir);
                                        if (dot < 0) continue;
                                        const projected = Vector3.method("op_Addition", 2).invoke(rayOrigin, Vector3.method("op_Multiply", 2).invoke(rayDir, dot));
                                        const perpDist = Vector3.method("Distance").invoke(npPos, projected);
                                        if (perpDist < bestDist) { bestDist = perpDist; targetNP = np; }
                                    } catch(_) {}
                                }
                            }
                            if (targetNP && !targetNP.isNull?.()) {
                                try {
                                    const pv = targetNP.field("photonView").value;
                                    const owner = pv.method("get_Owner").invoke();
                                    const actorNum = owner.method("get_ActorNumber").invoke() as number;
                                    if (frozenTargets.includes(actorNum)) {
                                        frozenTargets = frozenTargets.filter(a => a !== actorNum);
                                        console.log(`[KickGun] removed actor=${actorNum} remaining=${frozenTargets.length}`);
                                    } else {
                                        frozenTargets.push(actorNum);
                                        console.log(`[KickGun] added actor=${actorNum} total=${frozenTargets.length}`);
                                    }
                                } catch(_) {}
                            } else {
                                console.log(`[KickGun] no target found`);
                            }
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                    // Every 200ms: destroy the rig of all targeted players
                    if (frozenTargets.length === 0) return;
                    const nowFreeze = Date.now();
                    if (nowFreeze - lastKickTime < 200) return;
                    lastKickTime = nowFreeze;
                    try {
                        PhotonNetwork.method("get_CurrentRoom").invoke().method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
                        const allNPs = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
                        for (let i = 0; i < allNPs.length; i++) {
                            try {
                                const np = allNPs.get(i);
                                const pv = np.field("photonView").value;
                                if (pv == null) continue;
                                const owner = pv.method("get_Owner").invoke();
                                if (owner == null) continue;
                                if (!frozenTargets.includes(owner.method("get_ActorNumber").invoke() as number)) continue;
                                PhotonNetwork.method("DestroyPlayerObjects").invoke(owner);
                                sendAllOutgoing();
                            } catch(_) {}
                        }
                    } catch(_) {}
                },
                disableMethod: () => {
                    frozenTargets = [];
                    console.log(`[KickGun] cleared all targets`);
                },
            }),
            new ButtonInfo({
                buttonText: "Fling Gun",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            // First try: direct raycast hit
                            let targetNP = null;
                            try {
                                const ray = gunData.ray;
                                if (ray && !ray.handle?.isNull?.()) {
                                    const hitCollider = ray.method("get_collider").invoke();
                                    if (hitCollider && !hitCollider.isNull()) {
                                        try { targetNP = hitCollider.method("GetComponentInParent", 0).inflate(NetworkPlayer).invoke(); } catch(_) {}
                                        if (!targetNP || targetNP.isNull?.()) {
                                            try { targetNP = hitCollider.method("get_gameObject").invoke().method("GetComponentInParent", 0).inflate(NetworkPlayer).invoke(); } catch(_) {}
                                        }
                                    }
                                }
                            } catch(_) {}
                            // Fallback: nearest on ray line
                            if (!targetNP || targetNP.isNull?.()) {
                                const rayOrigin = rightHandTransform.method("get_position").invoke();
                                const rayDir = rightHandTransform.method("get_forward").invoke();
                                const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                                const allNPs = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
                                let bestDist = 3.0;
                                for (let i = 0; i < allNPs.length; i++) {
                                    try {
                                        const np = allNPs.get(i);
                                        const pv = np.field("photonView").value;
                                        if (pv == null) continue;
                                        const owner = pv.method("get_Owner").invoke();
                                        if (owner == null || owner.method("get_ActorNumber").invoke() === localId) continue;
                                        const npPos = getTransform(np.method("get_gameObject").invoke()).method("get_position").invoke();
                                        const toTarget = Vector3.method("op_Subtraction", 2).invoke(npPos, rayOrigin);
                                        const dot = Vector3.method("Dot").invoke(toTarget, rayDir);
                                        if (dot < 0) continue;
                                        const projected = Vector3.method("op_Addition", 2).invoke(rayOrigin, Vector3.method("op_Multiply", 2).invoke(rayDir, dot));
                                        const perpDist = Vector3.method("Distance").invoke(npPos, projected);
                                        if (perpDist < bestDist) { bestDist = perpDist; targetNP = np; }
                                    } catch(_) {}
                                }
                            }
                            if (targetNP && !targetNP.isNull?.()) {
                                try {
                                    const npGO = targetNP.method("get_gameObject").invoke();
                                    const npPos = getTransform(npGO).method("get_position").invoke();
                                    const rayOrigin = rightHandTransform.method("get_position").invoke();
                                    const dir = Vector3.method("op_Subtraction", 2).invoke(npPos, rayOrigin);
                                    const normalized = Vector3.method("Normalize").invoke(dir);
                                    const flingVel = Vector3.method("op_Multiply", 2).invoke(normalized, 40.0);
                                    let rb = getComponent(npGO, Rigidbody);
                                    if (rb == null) rb = getComponentInParent(npGO, Rigidbody);
                                    if (rb != null) rb.method("set_velocity").invoke(flingVel);
                                    console.log(`[FlingGun] flung: ${npGO.method("get_name").invoke()}`);
                                } catch(e) { console.log(`[FlingGun] error: ${e}`); }
                            } else {
                                console.log(`[FlingGun] no target found`);
                            }
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
                keepOn: true,
            }),
            new ButtonInfo({
                buttonText: "Telekinesis",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        const gunPos = getTransform(gunPointer).method("get_position").invoke();

                        if (rightTrigger) {
                            // No object locked yet — find the closest PhotonView object near the gun dot
                            if (tkLockedObject == null) {
                                const photonViews = Object.method("FindObjectsOfType").inflate(PhotonView).invoke();
                                const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                                let closestDist = 2.0;
                                for (let i = 0; i < photonViews.length; i++) {
                                    try {
                                        const pv = photonViews.get(i);
                                        const owner = pv.method("get_Owner").invoke();
                                        if (owner == null) continue;
                                        if (owner.method("get_ActorNumber").invoke() !== localId) continue;
                                        const obj = pv.method("get_gameObject").invoke();
                                        const objPos = getTransform(obj).method("get_position").invoke();
                                        const dist = Vector3.method("Distance").invoke(gunPos, objPos);
                                        if (dist < closestDist) {
                                            closestDist = dist;
                                            tkLockedObject = obj;
                                        }
                                    } catch (_) {}
                                }
                            }
                            // Move locked object to gun pointer position every frame
                            if (tkLockedObject != null) {
                                try {
                                    const rb = getComponent(tkLockedObject, Rigidbody);
                                    if (rb != null) {
                                        rb.method("set_isKinematic").invoke(true);
                                    }
                                    getTransform(tkLockedObject).method("set_position").invoke(gunPos);
                                } catch (_) { tkLockedObject = null; }
                            }
                        } else {
                            // Trigger released — drop the object
                            if (tkLockedObject != null) {
                                try {
                                    const rb = getComponent(tkLockedObject, Rigidbody);
                                    if (rb != null) {
                                        rb.method("set_isKinematic").invoke(false);
                                    }
                                } catch (_) {}
                                tkLockedObject = null;
                            }
                        }
                    } else {
                        // Grip released — drop
                        if (tkLockedObject != null) {
                            try {
                                const rb = getComponent(tkLockedObject, Rigidbody);
                                if (rb != null) rb.method("set_isKinematic").invoke(false);
                            } catch (_) {}
                            tkLockedObject = null;
                        }
                    }
                },
                keepOn: true,
            }),
        ],
        [ // Physics [11]
            new ButtonInfo({
                buttonText: "Orbit Items",
                enabled: false,
                method: () => {
                    try {
                        const now = Date.now();
                        // Rescan for owned items every 2 seconds instead of every frame
                        if (now - lastOrbitScanTime > 2000) {
                            lastOrbitScanTime = now;
                            orbitItems = [];
                            const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke();
                            const photonViews = Object.method("FindObjectsOfType").inflate(PhotonView).invoke();
                            for (let i = 0; i < photonViews.length; i++) {
                                try {
                                    const pv = photonViews.get(i);
                                    const owner = pv.method("get_Owner").invoke();
                                    if (owner == null) continue;
                                    if (owner.method("get_ActorNumber").invoke() !== localId) continue;
                                    const obj = pv.method("get_gameObject").invoke();
                                    const name = obj.method("get_name").invoke().toString();
                                    if (spawnablePrefabs.some(p => name.includes(p))) {
                                        const rb = getComponent(obj, Rigidbody);
                                        if (rb != null) rb.method("set_isKinematic").invoke(true);
                                        orbitItems.push(obj);
                                    }
                                } catch (_) {}
                            }
                        }
                        if (orbitItems.length === 0) return;
                        orbitAngle = (orbitAngle + 3.0) % 360;
                        const headPos = getTransform(headCollider).method("get_position").invoke();
                        const hx = headPos.field("x").value as number;
                        const hy = headPos.field("y").value as number;
                        const hz = headPos.field("z").value as number;
                        const angleStep = 360 / orbitItems.length;
                        for (let i = 0; i < orbitItems.length; i++) {
                            try {
                                const a = (orbitAngle + i * angleStep) * (Math.PI / 180);
                                getTransform(orbitItems[i]).method("set_position").invoke([
                                    hx + Math.cos(a) * orbitRadius,
                                    hy,
                                    hz + Math.sin(a) * orbitRadius
                                ]);
                            } catch (_) { orbitItems.splice(i, 1); i--; }
                        }
                    } catch (_) {}
                },
                disableMethod: () => {
                    for (let i = 0; i < orbitItems.length; i++) {
                        try {
                            const rb = getComponent(orbitItems[i], Rigidbody);
                            if (rb != null) rb.method("set_isKinematic").invoke(false);
                        } catch (_) {}
                    }
                    orbitItems = [];
                },
            }),
            new ButtonInfo({
                buttonText: "Orbit Radius+",
                method: () => { orbitRadius = Math.min(orbitRadius + 0.5, 15.0); },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Orbit Radius-",
                method: () => { orbitRadius = Math.max(orbitRadius - 0.5, 0.5); },
                keepOn: false,
            }),
            new ButtonInfo({
                buttonText: "Pull Items Here",
                method: () => {
                    if (rightGrab) {
                        const gunData = renderGun();
                        const gunPointer = gunData.gunPointer;
                        if (rightTrigger && !perviousTeleportKey) {
                            const gunPos = getTransform(gunPointer).method("get_position").invoke();
                            PhotonNetwork.method("get_CurrentRoom").invoke().method("SetMasterClient").invoke(PhotonNetwork.method("get_LocalPlayer").invoke());
                            setTimeout(() => {
                                const photonViews = Object.method("FindObjectsOfType").inflate(PhotonView).invoke();
                                for (let i = 0; i < photonViews.length; i++) {
                                    try {
                                        const pv = photonViews.get(i);
                                        if (pv == null) continue;
                                        const owner = pv.method("get_Owner").invoke();
                                        if (owner == null) continue; // skip unowned scene objects
                                        const obj = pv.method("get_gameObject").invoke();
                                        if (obj == null) continue;
                                        const name = obj.method("get_name").invoke().toString();
                                        const matched = spawnablePrefabs.find(p => name.includes(p));
                                        if (!matched) continue;
                                        console.log(`[PullItems] moving: ${name} owner=${owner.method("get_ActorNumber").invoke()}`);
                                        const rb = getComponent(obj, Rigidbody);
                                        if (rb != null) {
                                            rb.method("set_isKinematic").invoke(true);
                                            rb.method("set_velocity").invoke(zeroVector);
                                        }
                                        getTransform(obj).method("set_position").invoke(gunPos);
                                        if (rb != null) rb.method("set_isKinematic").invoke(false);
                                    } catch (e) {
                                        console.log(`[PullItems] error: ${e}`);
                                    }
                                }
                                sendAllOutgoing();
                            }, 1500);
                        }
                        perviousTeleportKey = rightTrigger;
                    }
                },
                keepOn: true,
            }),
        ],
    ];

    let buttonMap: Map<string, ButtonInfo> = new Map();
    buttons.flat().forEach(button => {
        buttonMap.set(button.buttonText, button);
    });

    function getIndex(buttonText: string): ButtonInfo {
        return buttonMap.get(buttonText);
    }

    const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
    ButtonActivation.implementation = function (collider) {
        const rawName = this.method("get_name").invoke().toString();

        if (rawName.length > 1 && rawName[1] == "@") {
            if (collider.handle.equals(referenceCollider.handle)) {
                const goName = rawName.substring(2, rawName.length - 1);
                const _time = Time.method("get_time").invoke();

                if (_time > buttonClickDelay) {
                    buttonClickDelay = _time + 0.2;

                    const button = getIndex(goName);
                    if (button) {
                        if (button.tooltip) showNotification(button.tooltip, 4);
                        if (button.keepOn) {
                            button.enabled = !button.enabled;
                            if (button?.enabled) {
                                button.enableMethod?.();
                            } else {
                                button?.disableMethod?.();
                            }
                        } else {
                            button?.method?.();
                        }
                        reloadMenu();
                    }
                }
            }
            return;
        }

        return this.method("OnTriggerEnter").invoke(collider);
    };

    const LateUpdate = GorillaTagger.method("LateUpdate");
    LateUpdate.implementation = function () {
        initNotifSlots(); // one-time setup, no-op after first frame
        OVRInputHandler.update();

        leftPrimary = OVRInputHandler.leftControllerPrimaryButton;
        leftSecondary = OVRInputHandler.leftControllerSecondaryButton;
        rightPrimary = OVRInputHandler.rightControllerPrimaryButton;
        rightSecondary = OVRInputHandler.rightControllerSecondaryButton;
        leftGrab = OVRInputHandler.leftGrab;
        rightGrab = OVRInputHandler.rightGrab;
        leftTrigger = OVRInputHandler.leftControllerTriggerButton;
        rightTrigger = OVRInputHandler.rightControllerTriggerButton;

        deltaTime = Time.method("get_deltaTime").invoke();
        time = Time.method("get_time").invoke();

        if (leftSecondary) {
            // If tooltip expired, rebuild to clear it
            if (menu != null && currentTooltip !== "" && Date.now() >= tooltipResetTime) {
                currentTooltip = "";
                reloadMenu();
            }
            if (menu == null) {
                renderMenu();
            } else {
                recenterMenu();
            }
        } else {
            if (menu != null) {
                Destroy(menu);
                menu = null;
            }
        }

        if (menu == null) {
            if (reference != null) { Destroy(reference); reference = null; }
        } else {
            if (reference == null) { renderReference(); }
        }

        try {
            if (GunPointer != null) {
                if (!(GunPointer.method("get_activeSelf").invoke())) {
                    Destroy(GunPointer); GunPointer = null;
                } else {
                    GunPointer.method("SetActive").invoke(false);
                }
            }
            let lineObj = GunLine.method("get_gameObject").invoke();
            if (lineObj != null) {
                if (!(lineObj.method("get_activeSelf").invoke())) {
                    Destroy(lineObj); GunLine = null;
                } else {
                    lineObj.method("SetActive").invoke(false);
                }
            }
        } catch { }

        buttons.flat()
            .filter(button => button.enabled)
            .forEach(button => {
                if (button.method) {
                    try {
                        button.method();
                    } catch (error) {
                        console.error(`Error executing method for button '${button.buttonText || 'unnamed'}':`, error);
                        if (error.stack) {
                            const stackLines = error.stack.split('\n');
                            if (stackLines.length > 1) {
                                console.error('Error occurred at:', stackLines[1].trim());
                            }
                        }
                    }
                }
            });

        // Hide expired HUD notification slots
        const nowHide = Date.now();
        for (const slot of notifSlots) {
            if (slot.go != null && nowHide > slot.expiry && slot.expiry > 0) {
                try { slot.go.method("SetActive").invoke(false); } catch(_) {}
            }
        }

        // Player join/leave detection — check every 2 seconds
        const nowJoin = Date.now();
        if (nowJoin - lastOrbitScanTime > 2000) {
            try {
                const allNPs = Object.method("FindObjectsOfType").inflate(NetworkPlayer).invoke();
                const localId = PhotonNetwork.method("get_LocalPlayer").invoke().method("get_ActorNumber").invoke() as number;
                const currentActors: Set<number> = new Set();
                for (let i = 0; i < allNPs.length; i++) {
                    try {
                        const np = allNPs.get(i);
                        const pv = np.field("photonView").value;
                        if (pv == null) continue;
                        const owner = pv.method("get_Owner").invoke();
                        if (owner == null) continue;
                        const actorNum = owner.method("get_ActorNumber").invoke() as number;
                        if (actorNum === localId) continue;
                        currentActors.add(actorNum);
                        if (lastPlayerCount >= 0 && !knownPlayerActors.has(actorNum)) {
                            // New player joined
                            const name = owner.method("get_NickName").invoke().toString();
                            showNotification(`${name || "Someone"} joined the lobby`, 4);
                        }
                    } catch(_) {}
                }
                // Check for leaves
                if (lastPlayerCount >= 0) {
                    for (const oldActor of knownPlayerActors) {
                        if (!currentActors.has(oldActor)) {
                            showNotification(`A player left the lobby`, 3);
                        }
                    }
                }
                knownPlayerActors = currentActors;
                lastPlayerCount = currentActors.size;
            } catch(_) {}
        }

        // RGB Rave theme — animate background color live every frame
        if (themeIndex === 10 && menu != null) {
            hue = (hue + 2) % 360; // advance hue every frame for smooth cycling
            try {
                const [r1, g1, b1] = hsl2Rgb(hue, 100, 50);  // outer panel - full brightness
                const [r2, g2, b2] = hsl2Rgb(hue, 100, 30);  // inner panel - same hue, darker
                if (menuBgRenderer != null) {
                    try {
                        const mat1 = menuBgRenderer.method("get_material").invoke();
                        mat1.method("set_shader").invoke(UberShader);
                        mat1.method("set_color").invoke([r1/255, g1/255, b1/255, 1.0]);
                    } catch(_) { menuBgRenderer = null; }
                }
                if (menuBg2Renderer != null) {
                    try {
                        const mat2 = menuBg2Renderer.method("get_material").invoke();
                        mat2.method("set_shader").invoke(UberShader);
                        mat2.method("set_color").invoke([r2/255, g2/255, b2/255, 1.0]);
                    } catch(_) { menuBg2Renderer = null; }
                }
            } catch(_) {}
        }

        return LateUpdate.invoke();
    };

    console.log(`Compiled ${new Date().toISOString()}`);

}, "main");